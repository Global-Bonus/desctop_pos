WEB TOOL: http://vgb-main-server.cloudapp.net:8080/vgb/web-tool/

Ссилка куда конектится нужно трифтом: http://vgb-main-server.cloudapp.net:8080/vgb/thrift/
она должна быть вынесена в параметры поскольку будет меняться
К ссылки добавляются суфиксы в зависимости от сервиса (в вебтуле справа)